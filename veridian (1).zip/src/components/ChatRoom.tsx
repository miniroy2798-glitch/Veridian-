import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { db } from '../lib/firebase';
import { doc, getDoc, collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, where, or } from 'firebase/firestore';
import { deriveSharedKey, encryptMessage, decryptMessage } from '../lib/crypto';
import { ArrowLeft, Send, Video, Image as ImageIcon, Mic, Square, Paperclip } from 'lucide-react';
import VideoCall from './VideoCall';

interface Message {
  id: string;
  senderId: string;
  ciphertext: string;
  iv: string;
  mediaType?: string;
  createdAt: any;
  plaintext?: string;
  imageUrl?: string;
}

export default function ChatRoom() {
  const { chatId } = useParams<{ chatId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [peer, setPeer] = useState<any>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [sharedKey, setSharedKey] = useState<CryptoKey | null>(null);
  const [callActive, setCallActive] = useState(false);
  const [incomingCallId, setIncomingCallId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (!chatId || !user) return;
    
    // Find peer ID
    const peerId = chatId.split('_').find(id => id !== user.uid);
    if (!peerId) return;

    const init = async () => {
      const chatDoc = await getDoc(doc(db, 'chats', chatId));
      if (!chatDoc.exists()) {
         navigate('/');
         return;
      }
      const chatData = chatDoc.data();
      
      if (chatData.isGroup) {
         setPeer({ displayName: chatData.name, isGroup: true, ...chatData });
         
         const myEncryptedKey = chatData.groupKeys?.[user.uid];
         if (myEncryptedKey && chatData.adminId) {
            const adminDoc = await getDoc(doc(db, 'users', chatData.adminId));
            if (adminDoc.exists() && adminDoc.data().publicKeyJwk) {
               const adminSharedKey = await deriveSharedKey(adminDoc.data().publicKeyJwk);
               if (adminSharedKey) {
                  const { decryptSymmetricKey } = await import('../lib/crypto');
                  const groupKey = await decryptSymmetricKey(adminSharedKey, myEncryptedKey.ciphertext, myEncryptedKey.iv);
                  setSharedKey(groupKey);
               }
            }
         }
      } else {
         const peerDoc = await getDoc(doc(db, 'users', peerId));
         if (peerDoc.exists()) {
           const peerData = peerDoc.data();
           setPeer(peerData);
           
           if (peerData.publicKeyJwk) {
              const key = await deriveSharedKey(peerData.publicKeyJwk);
              setSharedKey(key);
           }
         }
      }
    };
    init();
  }, [chatId, user]);

  useEffect(() => {
    if (!chatId || !sharedKey) return;
    
    const q = query(
      collection(db, 'chats', chatId, 'messages'),
      orderBy('createdAt', 'asc')
    );
    
    const unsub = onSnapshot(q, async (snapshot) => {
      const msgs: Message[] = [];
      for (const d of snapshot.docs) {
         const data = d.data() as Message;
         data.id = d.id;
         
         try {
           const decrypted = await decryptMessage(sharedKey, data.ciphertext, data.iv);
           if (data.mediaType?.startsWith('image/')) {
             data.imageUrl = decrypted; // We stored base64 image data directly
           } else {
             data.plaintext = decrypted;
           }
         } catch(e) {
           data.plaintext = "[Decryption Failed]";
         }
         msgs.push(data);
      }
      setMessages(msgs);
    });
    
    return () => unsub();
  }, [chatId, sharedKey]);

  // Listen for incoming calls
  useEffect(() => {
    if (!user) return;
    // We check the calls collection for any call where we are the callee and status is 'calling'
    const q = query(
      collection(db, 'calls'),
      where('calleeId', '==', user.uid)
    );
    const unsub = onSnapshot(q, (snapshot) => {
       for (const change of snapshot.docChanges()) {
          const callData = change.doc.data();
          if (change.type === 'added' || change.type === 'modified') {
             if (callData.calleeId === user.uid && callData.status === 'calling') {
                setIncomingCallId(change.doc.id);
             } else if (callData.status === 'ended') {
                setIncomingCallId(null);
             }
          }
       }
    });
    return () => unsub();
  }, [user]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !sharedKey || !chatId || !user) return;
    
    const plain = text;
    setText('');
    
    try {
      const { ciphertext, iv } = await encryptMessage(sharedKey, plain);
      
      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        senderId: user.uid,
        ciphertext,
        iv,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.error('Failed to send text', err);
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !sharedKey || !chatId || !user) return;
    
    // Check size < ~700KB before base64
    if (file.size > 700000) {
      alert('File too large. Max size is ~700KB for E2EE payload constraints.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const base64Str = ev.target?.result as string;
      try {
        const { ciphertext, iv } = await encryptMessage(sharedKey, base64Str);
        await addDoc(collection(db, 'chats', chatId, 'messages'), {
          senderId: user.uid,
          ciphertext,
          iv,
          mediaType: file.type,
          fileName: file.name,
          fileSize: file.size,
          createdAt: serverTimestamp()
        });
      } catch (err) {
        console.error('Failed to send file', err);
      }
    };
    reader.readAsDataURL(file);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      
      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(t => t.stop());
        
        if (audioBlob.size > 700000) {
           alert("Voice message too long.");
           setIsRecording(false);
           return;
        }

        const reader = new FileReader();
        reader.onload = async (ev) => {
          const base64Str = ev.target?.result as string;
          try {
            const { ciphertext, iv } = await encryptMessage(sharedKey!, base64Str);
            await addDoc(collection(db, 'chats', chatId!, 'messages'), {
              senderId: user!.uid,
              ciphertext,
              iv,
              mediaType: 'audio/webm',
              createdAt: serverTimestamp()
            });
          } catch (err) {
            console.error('Failed to send audio', err);
          }
        };
        reader.readAsDataURL(audioBlob);
      };
      
      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error(err);
      alert("Microphone permission denied");
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  return (
    <div className="flex-1 flex flex-col p-6 w-full max-w-2xl mx-auto h-[100dvh]">
      <div className="bg-white rounded-[32px] shadow-sm flex flex-col overflow-hidden h-full border border-[#f0f0e8]">
      <header className="h-20 border-b border-[#f5f5f0] px-8 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 -ml-4 text-[#a8a79d] hover:text-[#5A5A40] transition rounded-full hover:bg-[#f5f5f0]">
            <ArrowLeft size={20} />
          </button>
          
          {peer?.photoURL ? (
            <img src={peer.photoURL} alt="" className="w-10 h-10 rounded-full" />
          ) : (
            <div className="w-10 h-10 bg-[#8a9a5b] text-white rounded-full flex items-center justify-center font-bold">
              {peer?.displayName?.charAt(0) || '?'}
            </div>
          )}
          <div>
            <h2 className="font-serif font-bold text-lg leading-tight text-[#2d2d2a]">{peer?.displayName || 'Loading...'}</h2>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] uppercase tracking-wider text-[#5A5A40] font-bold">E2EE Verified</span>
              <div className="w-1 h-1 rounded-full bg-[#5A5A40]"></div>
            </div>
          </div>
        </div>
        
        <button 
           onClick={() => setCallActive(true)}
           className="px-6 py-2.5 rounded-full bg-[#5A5A40] hover:bg-[#4a4a35] text-white text-sm font-medium transition"
           title="Video Call"
        >
          <Video className="inline-block mr-2 -mt-0.5" size={16} />
          Call
        </button>
      </header>

      {/* Incoming Call Notification */}
      {incomingCallId && !callActive && (
         <div className="absolute top-24 left-1/2 -translate-x-1/2 bg-white border border-[#f5f5f0] p-4 rounded-2xl shadow-xl z-40 flex items-center gap-4 animate-pulse">
            <div className="w-12 h-12 rounded-full bg-[#8a9a5b] flex items-center justify-center text-white font-bold">
              {peer?.displayName?.charAt(0) || '?'}
            </div>
            <div>
               <p className="font-semibold text-[#2d2d2a]">{peer?.displayName}</p>
               <p className="text-xs text-[#8e8e8e]">Incoming Video Call</p>
            </div>
            <button onClick={() => setCallActive(true)} className="ml-4 bg-[#5A5A40] hover:bg-[#4a4a35] text-white px-4 py-2 rounded-full font-medium text-sm transition shadow-md">
              Answer
            </button>
         </div>
      )}

      {/* Main Chat Area */}
      <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-[#faf9f6]">
         {messages.map(msg => {
            const isMe = msg.senderId === user?.uid;
            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end ml-auto' : 'items-start'} max-w-[70%]`}>
                <div className={`p-4 rounded-[24px] ${
                  isMe ? 'bg-[#5A5A40] text-white rounded-tr-none shadow-md' : 'bg-white border border-[#f0f0e8] text-[#2d2d2a] rounded-tl-none shadow-sm'
                }`}>
                  {msg.imageUrl ? (
                    <img src={msg.imageUrl} alt="encrypted" className="rounded-xl w-full h-auto max-w-[240px]" />
                  ) : msg.mediaType ? (
                     msg.mediaType.startsWith('video/') ? (
                       <video src={msg.plaintext} controls className="rounded-xl w-full max-w-[240px]" />
                     ) : msg.mediaType.startsWith('audio/') ? (
                       <audio src={msg.plaintext} controls className="w-[240px]" />
                     ) : (
                       <a href={msg.plaintext} download={(msg as any).fileName || 'document'} className="flex flex-col items-center gap-2 p-2 bg-white/20 rounded-xl hover:bg-white/30 transition">
                         <span className="font-medium text-sm">{(msg as any).fileName || 'Encrypted File'}</span>
                         <span className="text-xs opacity-70">Download</span>
                       </a>
                     )
                  ) : (
                    <p className="break-words lg:break-normal text-sm">{msg.plaintext}</p>
                  )}
                </div>
                {msg.createdAt && (
                  <span className={`text-[10px] text-[#8e8e8e] mt-2 ${isMe ? 'mr-2' : 'ml-2'}`}>
                    {msg.createdAt?.toDate().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} {isMe && '• Delivered'}
                  </span>
                )}
              </div>
            );
         })}
         <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <footer className="h-24 p-6 flex items-center gap-4 bg-white border-t border-[#f5f5f0] shrink-0">
        <form onSubmit={handleSend} className="flex items-center gap-2 sm:gap-4 w-full">
          <input 
            type="file" 
            accept="image/*,video/*,audio/*,application/pdf" 
            ref={fileInputRef} 
            onChange={handleFileSelect} 
            className="hidden" 
          />
          <button 
             type="button" 
             onClick={() => fileInputRef.current?.click()}
             className="p-2 text-[#a8a79d] hover:text-[#5A5A40] rounded-full transition"
             title="Attach File"
          >
             <Paperclip size={24} />
          </button>
          
          <div className="flex-1 relative mx-2">
            <input
               type="text"
               value={text}
               onChange={e => setText(e.target.value)}
               placeholder="Write a secure message..."
               className="w-full bg-[#f5f5f0] border-none rounded-full py-4 pr-12 pl-6 text-sm text-[#2d2d2a] placeholder:text-[#a8a79d] focus:ring-1 focus:ring-[#5A5A40]"
               disabled={isRecording}
            />
          </div>
          
          {text.trim() ? (
            <button 
               type="submit" 
               className="w-12 h-12 shrink-0 flex items-center justify-center rounded-full bg-[#5A5A40] hover:bg-[#4a4a35] text-white transition shadow-sm"
            >
               <Send size={20} className="relative z-10 -ml-1" />
            </button>
          ) : (
            <button 
               type="button"
               onMouseDown={startRecording}
               onMouseUp={stopRecording}
               onTouchStart={startRecording}
               onTouchEnd={stopRecording}
               className={`w-12 h-12 shrink-0 flex items-center justify-center rounded-full transition shadow-sm ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-[#5A5A40] text-white hover:bg-[#4a4a35]'}`}
            >
               {isRecording ? <Square size={18} fill="currentColor" /> : <Mic size={20} />}
            </button>
          )}
        </form>
      </footer>
      </div>

      {/* Video Call Overlay */}
      {callActive && (
         <div className="absolute inset-0 z-50 bg-black flex flex-col">
            <VideoCall 
              chatId={chatId!} 
              peerId={peer?.uid} 
              onClose={() => {
                setCallActive(false);
                setIncomingCallId(null);
              }}
              existingCallId={incomingCallId}
            />
         </div>
      )}
    </div>
  );
}
