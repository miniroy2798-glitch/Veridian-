import { get, set } from 'idb-keyval';

const KEY_PAIR_KEY = 'chat_e2e_keypair';

export async function getOrGenerateKeyPair(): Promise<{ publicKeyJwk: JsonWebKey }> {
  const existingKey = await get<CryptoKey>(KEY_PAIR_KEY);
  if (existingKey) {
    const pubKey = await get<{ publicKey: CryptoKey }>('chat_e2e_pub_key');
    if (pubKey?.publicKey) {
       const jwk = await window.crypto.subtle.exportKey('jwk', pubKey.publicKey);
       return { publicKeyJwk: jwk };
    }
  }

  // Generate new
  const keyPair = await window.crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-384' },
    true, 
    ['deriveKey', 'deriveBits']
  );
  
  await set(KEY_PAIR_KEY, keyPair.privateKey);
  await set('chat_e2e_pub_key', { publicKey: keyPair.publicKey });
  
  const exportedPubKey = await window.crypto.subtle.exportKey('jwk', keyPair.publicKey);
  return { publicKeyJwk: exportedPubKey };
}

export async function getLocalPrivateKey(): Promise<CryptoKey | undefined> {
  return await get(KEY_PAIR_KEY);
}

export async function deriveSharedKey(peerPublicKeyJwkStr: string): Promise<CryptoKey | null> {
  const privateKey = await getLocalPrivateKey();
  if (!privateKey) return null;

  try {
    const peerPublicKeyJwk = JSON.parse(peerPublicKeyJwkStr);
    const peerPublicKey = await window.crypto.subtle.importKey(
      'jwk',
      peerPublicKeyJwk,
      { name: 'ECDH', namedCurve: 'P-384' },
      true,
      []
    );

    return await window.crypto.subtle.deriveKey(
      { name: 'ECDH', public: peerPublicKey },
      privateKey,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  } catch (err) {
    console.error("Key derivation failed", err);
    return null;
  }
}

function bufferToBase64(buffer: ArrayBuffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

function base64ToBuffer(base64: string) {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

export async function generateGroupKey(): Promise<CryptoKey> {
  return window.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
}

export async function exportKeyToBase64(key: CryptoKey): Promise<string> {
  const exported = await window.crypto.subtle.exportKey('raw', key);
  return bufferToBase64(exported);
}

export async function importKeyFromBase64(base64: string): Promise<CryptoKey> {
  const buffer = base64ToBuffer(base64);
  return window.crypto.subtle.importKey(
    'raw',
    buffer,
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
}

export async function encryptSymmetricKey(sharedKey: CryptoKey, keyToEncrypt: CryptoKey): Promise<{ ciphertext: string, iv: string }> {
  const rawKey = await window.crypto.subtle.exportKey('raw', keyToEncrypt);
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    sharedKey,
    rawKey
  );
  return {
    ciphertext: bufferToBase64(ciphertext),
    iv: bufferToBase64(iv.buffer)
  };
}

export async function decryptSymmetricKey(sharedKey: CryptoKey, ciphertextBase64: string, ivBase64: string): Promise<CryptoKey> {
  const ciphertext = base64ToBuffer(ciphertextBase64);
  const iv = base64ToBuffer(ivBase64);
  const decryptedBuffer = await window.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: new Uint8Array(iv) },
    sharedKey,
    ciphertext
  );
  return window.crypto.subtle.importKey(
    'raw',
    decryptedBuffer,
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
}

export async function encryptMessage(sharedKey: CryptoKey, plaintext: string) {
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    sharedKey,
    encoded
  );
  
  return {
    ciphertext: bufferToBase64(ciphertext),
    iv: bufferToBase64(iv.buffer)
  };
}

export async function decryptMessage(sharedKey: CryptoKey, ciphertextBase64: string, ivBase64: string) {
  const ciphertext = base64ToBuffer(ciphertextBase64);
  const iv = base64ToBuffer(ivBase64);
  
  const decrypted = await window.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: new Uint8Array(iv) },
    sharedKey,
    ciphertext
  );
  
  return new TextDecoder().decode(decrypted);
}
