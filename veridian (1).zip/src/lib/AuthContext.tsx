import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { getOrGenerateKeyPair } from './crypto';

interface AuthContextType {
  user: User | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, loading: true });

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (u) {
        // Ensure user profile & key pair is registered
        const userDocRef = doc(db, 'users', u.uid);
        const userDoc = await getDoc(userDocRef);
        
        let publicKeyJwkStr = '';
        if (userDoc.exists()) {
           publicKeyJwkStr = userDoc.data().publicKeyJwk;
        } else {
           // First time login - gen keys
           const { publicKeyJwk } = await getOrGenerateKeyPair();
           publicKeyJwkStr = JSON.stringify(publicKeyJwk);
           
           await setDoc(userDocRef, {
             uid: u.uid,
             displayName: u.displayName || 'Anonymous',
             email: u.email || '',
             photoURL: u.photoURL || '',
             publicKeyJwk: publicKeyJwkStr
           });
        }
      }
      setUser(u);
      setLoading(false);
    });

    return () => unsub();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
